const mongoose = require("mongoose");

const contactSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true, // Convert to lowercase for case-insensitive matching
      validate: {
        validator: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
        message: "Please enter a valid email address.",
      },
    },
    phone: { type: String, required: true, trim: true },
    company: { type: String, trim: true },
    jobPosition: { type: String, trim: true },
    enquiryReason: { type: String, required: true, trim: true },
    country: { type: String, required: true, trim: true },
    state: { type: String, required: true, trim: true },
    city: { type: String, required: true, trim: true },
    zip: { type: String, required: true, trim: true },
    message: { type: String, trim: true },
  },
  {
    timestamps: true,
  }
);

const Contact = mongoose.model("contacts", contactSchema);

module.exports = Contact;
